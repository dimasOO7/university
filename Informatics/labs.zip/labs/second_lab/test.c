#include <stdlib.h>
#include <stdio.h>
#include <math.h>
void main(){
    double x =24457777777777777777777777745645745745766756.0;
    while (1)
    {
        x /= 1.1;
        printf("%lg",x);
    }
    
}